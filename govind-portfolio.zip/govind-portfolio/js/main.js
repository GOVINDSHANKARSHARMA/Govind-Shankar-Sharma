(() => {
  'use strict';
  const root = document.documentElement;
  const menuToggle = document.getElementById('menuToggle');
  const siteNav = document.getElementById('siteNav');
  const themeToggle = document.getElementById('themeToggle');
  const backToTop = document.getElementById('backToTop');
  const currentYear = document.getElementById('year');

  if (currentYear) currentYear.textContent = new Date().getFullYear();

  // Theme preference is stored locally when the browser supports it.
  let savedTheme = null;
  try { savedTheme = localStorage.getItem('gs-portfolio-theme'); } catch (_) { /* Storage may be disabled. */ }
  if (savedTheme === 'light' || savedTheme === 'dark') root.dataset.theme = savedTheme;
  function syncThemeButton() {
    if (!themeToggle) return;
    const light = root.dataset.theme === 'light';
    themeToggle.setAttribute('aria-label', light ? 'Switch to dark theme' : 'Switch to light theme');
    const label = themeToggle.querySelector('.theme-label');
    const icon = themeToggle.querySelector('.theme-icon');
    if (label) label.textContent = light ? 'Dark mode' : 'Light mode';
    if (icon) icon.textContent = light ? '☾' : '☼';
  }
  syncThemeButton();
  themeToggle?.addEventListener('click', () => {
    root.dataset.theme = root.dataset.theme === 'light' ? 'dark' : 'light';
    try { localStorage.setItem('gs-portfolio-theme', root.dataset.theme); } catch (_) { /* The toggle still works for this visit. */ }
    syncThemeButton();
  });

  function closeMenu() {
    siteNav?.classList.remove('is-open');
    menuToggle?.setAttribute('aria-expanded', 'false');
    menuToggle?.setAttribute('aria-label', 'Open navigation');
  }
  menuToggle?.addEventListener('click', () => {
    const isOpen = menuToggle.getAttribute('aria-expanded') === 'true';
    menuToggle.setAttribute('aria-expanded', String(!isOpen));
    menuToggle.setAttribute('aria-label', isOpen ? 'Open navigation' : 'Close navigation');
    siteNav?.classList.toggle('is-open', !isOpen);
  });
  siteNav?.querySelectorAll('a').forEach(link => link.addEventListener('click', closeMenu));
  document.addEventListener('keydown', event => { if (event.key === 'Escape') closeMenu(); });

  const revealItems = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -35px 0px' });
    revealItems.forEach(item => observer.observe(item));
  } else {
    revealItems.forEach(item => item.classList.add('is-visible'));
  }

  function syncBackToTop() { backToTop?.classList.toggle('visible', window.scrollY > 600); }
  window.addEventListener('scroll', syncBackToTop, { passive: true });
  syncBackToTop();
  backToTop?.addEventListener('click', () => window.scrollTo({ top: 0, behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' }));

  // Opens the visitor's email app with the message filled in (no backend needed).
  const contactForm = document.getElementById('contactForm');
  const formStatus = document.getElementById('formStatus');
  contactForm?.addEventListener('submit', event => {
    event.preventDefault();
    const f = new FormData(contactForm);
    const subject = `${f.get('topic')} - message from ${f.get('name')}`;
    const body = `${f.get('message')}\n\nFrom: ${f.get('name')} (${f.get('email')})`;
    window.location.href = `mailto:govindshankar0135@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    if (formStatus) formStatus.textContent = 'Opening your email app. If nothing opens, write to govindshankar0135@gmail.com directly.';
  });
})();
